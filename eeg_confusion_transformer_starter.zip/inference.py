import argparse, os, numpy as np, torch, pandas as pd
from data_prep import load_eeg_sequences, train_test_zscore
from models import EEGTransformer, EEGConvTransformer, EEGBiLSTM

def get_model(name: str, in_feats=12):
    if name == "transformer":
        return EEGTransformer(in_feats=in_feats)
    elif name == "conv_transformer":
        return EEGConvTransformer(in_feats=in_feats)
    elif name == "bilstm":
        return EEGBiLSTM(in_feats=in_feats)
    else:
        raise ValueError(name)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--model", default="transformer", choices=["transformer","conv_transformer","bilstm"])
    args = ap.parse_args()

    X, y, groups, meta = load_eeg_sequences(args.csv)
    mask = meta["mask"]

    # Use simple global normalization (or load fold-specific stats if available)
    mu = X[mask>0].reshape(-1,X.shape[-1]).mean(axis=0)
    sd = X[mask>0].reshape(-1,X.shape[-1]).std(axis=0) + 1e-6
    Xn = (X - mu.reshape(1,1,-1)) / sd.reshape(1,1,-1)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = get_model(args.model, in_feats=X.shape[-1]).to(device)
    model.load_state_dict(torch.load(args.ckpt, map_location=device))
    model.eval()

    with torch.no_grad():
        xb = torch.tensor(Xn, dtype=torch.float32, device=device)
        mb = torch.tensor(mask, dtype=torch.float32, device=device)
        prob = torch.sigmoid(model(xb, mask=mb)).cpu().numpy().ravel()
    pred = (prob >= 0.5).astype(int)
    out = pd.DataFrame({"prob": prob, "pred": pred})
    out.to_csv("inference_out.csv", index=False)
    print("Saved inference_out.csv")

if __name__ == "__main__":
    main()
