import argparse, os, time, json
import numpy as np
import pandas as pd
import torch
from torch import nn
from sklearn.metrics import accuracy_score, f1_score, roc_auc_score

from data_prep import load_eeg_sequences, train_test_zscore, DEFAULT_FEATURES
from models import EEGTransformer, EEGConvTransformer, EEGBiLSTM
from utils import set_seed, EarlyStopper


# -------------------------------
# Model getter
# -------------------------------
def get_model(name: str, in_feats=12):
    if name == "transformer":
        return EEGTransformer(in_feats=in_feats, d_model=64, nhead=4, num_layers=3, ff=256, dropout=0.2)
    elif name == "conv_transformer":
        return EEGConvTransformer(in_feats=in_feats, d_model=64, nhead=4, num_layers=3, ff=256, dropout=0.2)
    elif name == "bilstm":
        return EEGBiLSTM(in_feats=in_feats, hidden=64, layers=1, dropout=0.2)
    else:
        raise ValueError(f"Unknown model: {name}")


# -------------------------------
# Focal loss
# -------------------------------
def focal_loss(logits, targets, alpha=0.25, gamma=2.0):
    bce = nn.functional.binary_cross_entropy_with_logits(logits, targets, reduction='none')
    p = torch.sigmoid(logits)
    pt = targets * p + (1-targets) * (1-p)
    loss = (alpha * (1-pt)**gamma * bce).mean()
    return loss


# -------------------------------
# Training one fold
# -------------------------------
def train_one_fold(model, trX, trY, trM, vaX, vaY, vaM, args):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = model.to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-2)
    if args.loss == "bce":
        criterion = nn.BCEWithLogitsLoss()
    else:
        criterion = lambda logits, y: focal_loss(logits, y, alpha=args.focal_alpha, gamma=args.focal_gamma)

    B = args.batch_size
    n = trX.shape[0]
    stopper = EarlyStopper(patience=args.patience, mode='max')
    history = []
    for epoch in range(1, args.epochs+1):
        model.train()
        # shuffle indices
        idx = np.random.permutation(n)
        for i in range(0, n, B):
            j = idx[i:i+B]
            xb = torch.tensor(trX[j], dtype=torch.float32, device=device)
            mb = torch.tensor(trM[j], dtype=torch.float32, device=device)
            yb = torch.tensor(trY[j], dtype=torch.float32, device=device)
            # simple time masking augmentation
            if args.time_mask_prob > 0:
                with torch.no_grad():
                    mask = (torch.rand_like(mb) < args.time_mask_prob) & (mb>0)
                    mb = mb.clone()
                    mb[mask] = 0
            logits = model(xb, mask=mb)
            loss = criterion(logits, yb)
            opt.zero_grad(); loss.backward(); opt.step()

        # validation (only Acc + F1)
        model.eval()
        with torch.no_grad():
            xb = torch.tensor(vaX, dtype=torch.float32, device=device)
            mb = torch.tensor(vaM, dtype=torch.float32, device=device)
            logits = model(xb, mask=mb)
            prob = torch.sigmoid(logits).cpu().numpy().ravel()

        pred = (prob >= 0.5).astype(np.int64)
        acc = accuracy_score(vaY, pred)
        f1  = f1_score(vaY, pred)

        history.append({"epoch": epoch, "val_acc": acc, "val_f1": f1})
        improved = stopper.step(f1, model)
        if stopper.should_stop():
            break
    stopper.restore(model)
    return model, history


# -------------------------------
# Main script
# -------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", type=str, required=True)
    ap.add_argument("--model", type=str, default="transformer", choices=["transformer","conv_transformer","bilstm"])
    ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--batch_size", type=int, default=32)
    ap.add_argument("--lr", type=float, default=1e-3)
    ap.add_argument("--loss", type=str, default="bce", choices=["bce","focal"])
    ap.add_argument("--focal_alpha", type=float, default=0.25)
    ap.add_argument("--focal_gamma", type=float, default=2.0)
    ap.add_argument("--patience", type=int, default=8)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--time_mask_prob", type=float, default=0.0,
                    help="Probability of masking out timesteps (augmentation)")
    args = ap.parse_args()

    set_seed(args.seed)
    X, y, groups, meta = load_eeg_sequences(args.csv)
    mask = meta["mask"]
    F = X.shape[-1]
    model_name = args.model

    # LOSO CV
    subjects = np.unique(groups)
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    run_dir = os.path.join("runs", f"{model_name}-{timestamp}")
    os.makedirs(run_dir, exist_ok=True)
    all_metrics = []
    global_probs, global_labels = [], []   # For global AUC

    for sid in subjects:
        tr_idx = groups != sid
        va_idx = groups == sid
        trX, trM, trY = X[tr_idx], mask[tr_idx], y[tr_idx]
        vaX, vaM, vaY = X[va_idx], mask[va_idx], y[va_idx]

        # z-score with training fold stats
        trXn, vaXn, mu, sd = train_test_zscore(trX, vaX, trM, vaM)

        model = get_model(model_name, in_feats=F)
        model, hist = train_one_fold(model, trXn, trY, trM, vaXn, vaY, vaM, args)

        # Evaluate
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        with torch.no_grad():
            px = torch.tensor(vaXn, dtype=torch.float32, device=device)
            pm = torch.tensor(vaM, dtype=torch.float32, device=device)
            prob = torch.sigmoid(model(px, mask=pm)).cpu().numpy().ravel()
        pred = (prob >= 0.5).astype(np.int64)
        acc = accuracy_score(vaY, pred)
        f1  = f1_score(vaY, pred)

        # Save fold artifacts
        fold_dir = os.path.join(run_dir, f"subject_{sid}")
        os.makedirs(fold_dir, exist_ok=True)
        torch.save(model.state_dict(), os.path.join(fold_dir, "best.pt"))
        pd.DataFrame(hist).to_csv(os.path.join(fold_dir, "history.csv"), index=False)
        pd.DataFrame({"prob": prob, "pred": pred, "label": vaY}).to_csv(os.path.join(fold_dir, "preds.csv"), index=False)
        with open(os.path.join(fold_dir, "norm_stats.json"), "w") as f:
            json.dump({"mu": mu.tolist(), "sd": sd.tolist(), "features": DEFAULT_FEATURES}, f)

        all_metrics.append({"subject": int(sid), "acc": acc, "f1": f1})
        print(f"[SID {sid}] acc={acc:.3f} f1={f1:.3f}")

        # Collect for global AUC
        global_probs.extend(prob)
        global_labels.extend(vaY)

    # Save per-subject metrics
    pd.DataFrame(all_metrics).to_csv(os.path.join(run_dir, "cv_metrics.csv"), index=False)
    avg = pd.DataFrame(all_metrics).mean(numeric_only=True)
    print("CV mean:", avg.to_dict())

    # Compute global AUC
    global_auc = roc_auc_score(global_labels, global_probs)
    print(f"Global ROC-AUC: {global_auc:.3f}")
    with open(os.path.join(run_dir, "global_auc.txt"), "w") as f:
        f.write(str(global_auc))


if __name__ == "__main__":
    main()
