import argparse, os, numpy as np, pandas as pd, torch
import matplotlib.pyplot as plt

from data_prep import load_eeg_sequences, train_test_zscore, DEFAULT_FEATURES
from models import EEGTransformer, EEGConvTransformer
from utils import set_seed

def get_model(name: str, in_feats=12):
    if name == "transformer":
        return EEGTransformer(in_feats=in_feats)
    elif name == "conv_transformer":
        return EEGConvTransformer(in_feats=in_feats)
    else:
        raise ValueError("Visualization supports transformer or conv_transformer")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--ckpt", required=True)
    ap.add_argument("--model", default="transformer", choices=["transformer","conv_transformer"])
    ap.add_argument("--outdir", default="viz_out")
    args = ap.parse_args()

    set_seed(42)
    X, y, groups, meta = load_eeg_sequences(args.csv)
    mask = meta["mask"]
    F = X.shape[-1]

    # Simple normalization using all data stats (only for visualization convenience)
    mu = X[mask>0].reshape(-1,F).mean(axis=0)
    sd = X[mask>0].reshape(-1,F).std(axis=0) + 1e-6
    Xn = (X - mu.reshape(1,1,-1)) / sd.reshape(1,1,-1)

    os.makedirs(args.outdir, exist_ok=True)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = get_model(args.model, in_feats=F).to(device)
    model.load_state_dict(torch.load(args.ckpt, map_location=device))
    model.eval()

    # Pick a few samples (first 5)
    idxs = np.arange(min(5, Xn.shape[0]))
    for i in idxs:
        xb = torch.tensor(Xn[i:i+1], dtype=torch.float32, device=device)
        mb = torch.tensor(mask[i:i+1], dtype=torch.float32, device=device)
        with torch.no_grad():
            logits, attn_list = model(xb, mask=mb, return_attn=True)
            prob = torch.sigmoid(logits).item()
        # Attention from last layer, averaged over heads
        attn = attn_list[-1].mean(dim=1)[0].detach().cpu().numpy()  # [T,T]
        T = int(mb.sum().item())
        attn_T = attn[:T,:T]

        # Plot temporal attention (average over query dimension)
        attn_time = attn_T.mean(axis=0)  # importance per timestep
        plt.figure()
        plt.plot(attn_time)
        plt.title(f"Temporal attention — sample {i} (p={prob:.2f})")
        plt.xlabel("time"); plt.ylabel("attention")
        plt.savefig(os.path.join(args.outdir, f"sample_{i}_attn_time.png"))
        plt.close()

        # Simple gradient * input saliency per feature
        xb.requires_grad_(True)
        logits = model(xb, mask=mb)  # no return_attn here
        logits.sum().backward()
        sal = (xb.grad * xb).detach().cpu().numpy()[0]  # [T,F]
        feat_importance = sal[:T].mean(axis=0)          # [F]

        plt.figure()
        plt.bar(np.arange(F), feat_importance)
        plt.xticks(np.arange(F), DEFAULT_FEATURES, rotation=60)
        plt.title(f"Feature importance (grad*input) — sample {i}")
        plt.tight_layout()
        plt.savefig(os.path.join(args.outdir, f"sample_{i}_feat_importance.png"))
        plt.close()

if __name__ == "__main__":
    main()
