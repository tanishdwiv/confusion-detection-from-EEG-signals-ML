import os, random, math, json
import numpy as np
import torch

def set_seed(seed: int = 42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def masked_mean(x, mask, dim=1, keepdim=False):
    # x: [B, T, D], mask: [B, T] with 1 for valid, 0 for pad
    denom = mask.sum(dim=dim, keepdim=True).clamp(min=1.0)
    m = (x * mask.unsqueeze(-1)).sum(dim=dim, keepdim=True) / denom.unsqueeze(-1)
    return m if keepdim else m.squeeze(dim)

class EarlyStopper:
    def __init__(self, patience=8, mode='max'):
        self.best = None
        self.patience = patience
        self.mode = mode
        self.wait = 0
        self.best_state = None
    def step(self, score, model):
        improved = (self.best is None) or ((score > self.best) if self.mode=='max' else (score < self.best))
        if improved:
            self.best = score
            self.best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            self.wait = 0
            return True
        else:
            self.wait += 1
            return False
    def should_stop(self):
        return self.wait >= self.patience
    def restore(self, model):
        if self.best_state is not None:
            model.load_state_dict(self.best_state)
