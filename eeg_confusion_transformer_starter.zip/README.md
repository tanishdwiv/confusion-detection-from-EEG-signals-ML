# EEG Confusion Detection — Transformer-based (Time-Series)

End-to-end code to train Transformer models for **confusion detection** from EEG signals,
tailored to the uploaded dataset schema: sequences grouped by **(SubjectID, VideoID)** with 12 EEG features and two label columns (`predefinedlabel`, `user-definedlabeln`).

## 1) Setup
```bash
# (optional) python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## 2) Train (Leave-One-Subject-Out CV)
```bash
# Transformer baseline
python train.py --csv /mnt/data/EEG_data.csv --model transformer --epochs 50

# Hybrid Conv+Transformer (often stronger)
python train.py --csv /mnt/data/EEG_data.csv --model conv_transformer --epochs 50

# BiLSTM baseline (for comparison)
python train.py --csv /mnt/data/EEG_data.csv --model bilstm --epochs 50
```

Artifacts will be written under `runs/<timestamp>/` per fold: metrics, best model, and predictions.

## 3) Visualize attention & feature saliency
```bash
# Save attention heatmaps and gradient*input feature importances for a few samples
python visualize.py --csv /mnt/data/EEG_data.csv --ckpt <path to a saved .pt model> --model transformer
```

## 4) Inference on new data
```bash
python inference.py --csv /mnt/data/EEG_data.csv --ckpt <path to .pt model> --model transformer
```

## Notes
- Splits are **subject-wise** using `SubjectID` (Leave-One-Subject-Out). No subject leakage.
- Sequences are defined as all rows sharing `(SubjectID, VideoID)`, ordered by file order.
- Label is taken from `user-definedlabeln` when available, else `predefinedlabel`. If variation within a sequence is detected, a **majority vote** is used.
- Features used (12): Attention, Mediation, Raw, Delta, Theta, Alpha1, Alpha2, Beta1, Beta2, Gamma1, Gamma2.
- Models support **padding masks**, so variable sequence lengths are fine.
- Metrics: Accuracy, macro-F1, AUROC. Early stopping on macro-F1.
- Advanced options: focal loss, time masking augmentation, mixup, self-distillation logits ensembling across seeds.

Good luck! Tweak hyperparameters in `train.py` CLI flags or inside `configs`.
