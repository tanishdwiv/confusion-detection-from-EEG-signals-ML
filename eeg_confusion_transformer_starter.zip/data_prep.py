import pandas as pd
import numpy as np
from typing import List, Tuple, Optional, Dict

DEFAULT_FEATURES = [
    "Attention","Mediation","Raw","Delta","Theta",
    "Alpha1","Alpha2","Beta1","Beta2","Gamma1","Gamma2"
]

def load_eeg_sequences(csv_path: str,
                       features: List[str] = DEFAULT_FEATURES,
                       subject_col: str = "SubjectID",
                       video_col: str = "VideoID",
                       primary_label: str = "user-definedlabeln",
                       fallback_label: str = "predefinedlabel"
                      ) -> Tuple[np.ndarray, np.ndarray, np.ndarray, Dict]:
    """
    Returns:
      X: float32 [N_seq, T_max, F] (padded)
      y: int64   [N_seq]
      groups: int64 [N_seq] (subject IDs for GroupKFold)
      meta: dict with 'lengths', 'seq_keys', 'features'
    """
    df = pd.read_csv(csv_path)
    assert subject_col in df.columns and video_col in df.columns, "SubjectID/VideoID columns required"
    assert all(f in df.columns for f in features), "Missing required feature columns"
    assert primary_label in df.columns or fallback_label in df.columns, "Missing label columns"

    # Choose label column
    label_col = primary_label if primary_label in df.columns else fallback_label

    # Build sequences grouped by (subject, video)
    grp = df.groupby([subject_col, video_col], sort=False)
    seq_keys = list(grp.groups.keys())

    # Check label consistency, majority vote if not constant
    labels = []
    seq_arrays = []
    lengths = []
    subjects = []
    for (sid, vid), g in grp:
        f = g[features].values.astype("float32")
        seq_arrays.append(f)
        lengths.append(len(f))
        subjects.append(int(sid))
        lab_vals = g[label_col].values
        # majority vote to handle rare flips
        if len(np.unique(lab_vals)) == 1:
            lab = int(lab_vals[0])
        else:
            counts = np.bincount(lab_vals.astype(int), minlength=2)
            lab = int(np.argmax(counts))
        labels.append(lab)

    # Pad sequences to max len
    T_max = max(lengths)
    F = len(features)
    N = len(seq_arrays)
    X = np.zeros((N, T_max, F), dtype="float32")
    mask = np.zeros((N, T_max), dtype="float32")
    for i, arr in enumerate(seq_arrays):
        t = arr.shape[0]
        X[i, :t] = arr
        mask[i, :t] = 1.0
    y = np.array(labels, dtype="int64")
    groups = np.array(subjects, dtype="int64")
    meta = {"lengths": np.array(lengths, dtype="int32"),
            "seq_keys": seq_keys,
            "features": features,
            "mask": mask}
    return X, y, groups, meta

def train_test_zscore(train_X: np.ndarray, test_X: np.ndarray, train_mask: np.ndarray, test_mask: np.ndarray):
    # Compute feature-wise stats using only valid (unmasked) steps from train
    B, T, F = train_X.shape
    valid = train_mask > 0
    mu = np.zeros(F, dtype=np.float32)
    sd = np.zeros(F, dtype=np.float32)
    for f in range(F):
        vals = train_X[:,:,f][valid]
        mu[f] = vals.mean()
        sd[f] = vals.std() + 1e-6
    def apply(X, mask):
        Xn = X.copy()
        Xn = (Xn - mu.reshape(1,1,-1)) / sd.reshape(1,1,-1)
        return Xn
    return apply(train_X, train_mask), apply(test_X, test_mask), mu, sd
