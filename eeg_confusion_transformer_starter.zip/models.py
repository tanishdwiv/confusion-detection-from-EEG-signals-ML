import math, torch
from torch import nn
from typing import Optional

class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 5000):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer('pe', pe.unsqueeze(0))  # [1, L, d]
    def forward(self, x):
        L = x.size(1)
        return x + self.pe[:, :L, :]

class TransformerEncoderLayerWithAttn(nn.Module):
    def __init__(self, d_model, nhead, dim_feedforward=256, dropout=0.2, batch_first=True):
        super().__init__()
        self.self_attn = nn.MultiheadAttention(d_model, nhead, dropout=dropout, batch_first=batch_first)
        self.linear1 = nn.Linear(d_model, dim_feedforward)
        self.dropout = nn.Dropout(dropout)
        self.linear2 = nn.Linear(dim_feedforward, d_model)
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout1 = nn.Dropout(dropout)
        self.dropout2 = nn.Dropout(dropout)
        self.act = nn.GELU()

    def forward(self, src, src_key_padding_mask=None, need_weights=False):
        attn_output, attn_weights = self.self_attn(src, src, src, key_padding_mask=src_key_padding_mask, need_weights=True, average_attn_weights=False)
        src = src + self.dropout1(attn_output)
        src = self.norm1(src)
        ff = self.linear2(self.dropout(self.act(self.linear1(src))))
        src = src + self.dropout2(ff)
        src = self.norm2(src)
        if need_weights:
            return src, attn_weights  # [B, heads, T, T]
        else:
            return src, None

class EEGTransformer(nn.Module):
    def __init__(self, in_feats=12, d_model=64, nhead=4, num_layers=3, ff=256, dropout=0.2, use_pos=True):
        super().__init__()
        self.input_proj = nn.Linear(in_feats, d_model)
        self.pos = PositionalEncoding(d_model) if use_pos else nn.Identity()
        self.layers = nn.ModuleList([TransformerEncoderLayerWithAttn(d_model, nhead, ff, dropout) for _ in range(num_layers)])
        self.norm = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, 1)
    def forward(self, x, mask=None, return_attn=False):
        # x: [B, T, F]; mask: [B, T]==1 for valid, 0 for pad -> key_padding_mask expects True for pad
        key_pad = None
        if mask is not None:
            key_pad = (mask == 0)  # True where pad
        h = self.input_proj(x)
        h = self.pos(h)
        attn_list = []
        for layer in self.layers:
            h, attn = layer(h, src_key_padding_mask=key_pad, need_weights=return_attn)
            if return_attn:
                attn_list.append(attn)  # [B, H, T, T]
        h = self.norm(h)
        # masked mean pooling
        if mask is not None:
            denom = mask.sum(dim=1, keepdim=True).clamp(min=1.0)
            pooled = (h * mask.unsqueeze(-1)).sum(dim=1) / denom
        else:
            pooled = h.mean(dim=1)
        logits = self.head(pooled).squeeze(-1)
        if return_attn:
            return logits, attn_list
        return logits

class EEGConvTransformer(nn.Module):
    def __init__(self, in_feats=12, d_model=64, nhead=4, num_layers=3, ff=256, dropout=0.2, use_pos=True):
        super().__init__()
        # light 1D conv front-end
        self.conv = nn.Sequential(
            nn.Conv1d(in_feats, 32, kernel_size=5, padding=2),
            nn.GELU(),
            nn.Conv1d(32, 32, kernel_size=5, padding=2),
            nn.GELU(),
        )
        self.proj = nn.Linear(32, d_model)
        self.pos = PositionalEncoding(d_model) if use_pos else nn.Identity()
        self.layers = nn.ModuleList([TransformerEncoderLayerWithAttn(d_model, nhead, ff, dropout) for _ in range(num_layers)])
        self.norm = nn.LayerNorm(d_model)
        self.head = nn.Linear(d_model, 1)

    def forward(self, x, mask=None, return_attn=False):
        # x: [B, T, F] -> conv expects [B, F, T]
        key_pad = None
        if mask is not None:
            key_pad = (mask == 0)
        x = x.transpose(1,2)                      # [B,F,T]
        h = self.conv(x).transpose(1,2)           # [B,T,32]
        h = self.proj(h)                          # [B,T,d]
        h = self.pos(h)
        attn_list = []
        for layer in self.layers:
            h, attn = layer(h, src_key_padding_mask=key_pad, need_weights=return_attn)
            if return_attn:
                attn_list.append(attn)
        h = self.norm(h)
        if mask is not None:
            denom = mask.sum(dim=1, keepdim=True).clamp(min=1.0)
            pooled = (h * mask.unsqueeze(-1)).sum(dim=1) / denom
        else:
            pooled = h.mean(dim=1)
        logits = self.head(pooled).squeeze(-1)
        if return_attn:
            return logits, attn_list
        return logits

class EEGBiLSTM(nn.Module):
    def __init__(self, in_feats=12, hidden=64, layers=1, dropout=0.2):
        super().__init__()
        self.lstm = nn.LSTM(input_size=in_feats, hidden_size=hidden, num_layers=layers,
                            batch_first=True, dropout=dropout if layers>1 else 0, bidirectional=True)
        self.head = nn.Sequential(nn.LayerNorm(hidden*2), nn.Linear(hidden*2, 1))
    def forward(self, x, mask=None):
        h, _ = self.lstm(x)
        if mask is not None:
            denom = mask.sum(dim=1, keepdim=True).clamp(min=1.0)
            pooled = (h * mask.unsqueeze(-1)).sum(dim=1) / denom
        else:
            pooled = h.mean(dim=1)
        return self.head(pooled).squeeze(-1)
